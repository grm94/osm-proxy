#!/bin/bash

juju attach lcm image=rocks.canonical.com:443/canonicalosm/lcm:v9.1.1-15
juju attach nbi image=rocks.canonical.com:443/canonicalosm/nbi:v9.1.1-11
juju attach mon image=rocks.canonical.com:443/canonicalosm/mon:v9.1.1-7
juju attach ro image=rocks.canonical.com:443/canonicalosm/ro:v9.1.1-8
juju attach pol image=rocks.canonical.com:443/canonicalosm/pol:v9.1.1-2
juju attach ng-ui image=rocks.canonical.com:443/canonicalosm/ng-ui:v9.1.1-3

