#!/bin/bash

juju scale-application -m osm grafana 0
juju scale-application -m osm prometheus 0
juju scale-application -m osm kafka-k8s 0
juju scale-application -m osm keystone 0
juju scale-application -m osm lcm 0
juju scale-application -m osm mon 0
juju scale-application -m osm nbi 0
juju scale-application -m osm ng-ui 0
juju scale-application -m osm pol 0
juju scale-application -m osm ro 0
juju scale-application -m osm zookeeper-k8s 0

