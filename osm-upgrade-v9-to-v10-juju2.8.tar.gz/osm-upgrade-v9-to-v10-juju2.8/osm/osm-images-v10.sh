#!/bin/bash

juju attach lcm image=rocks.canonical.com:443/canonicalosm/lcm:v10.1.0-0
juju attach nbi image=rocks.canonical.com:443/canonicalosm/nbi:v10.1.0-0
juju attach mon image=rocks.canonical.com:443/canonicalosm/mon:v10.1.0-0
juju attach ro image=rocks.canonical.com:443/canonicalosm/ro:v10.1.0-0
juju attach ng-ui image=rocks.canonical.com:443/canonicalosm/ng-ui:v10.1.0-0
juju attach pol image=rocks.canonical.com:443/canonicalosm/pol:v10.1.0-0


