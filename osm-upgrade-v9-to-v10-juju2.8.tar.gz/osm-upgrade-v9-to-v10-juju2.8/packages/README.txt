
helm repo add grafana https://grafana.github.io/helm-charts
helm fetch grafana/grafana

osm nfpkg-create grafana_knf
osm nspkg-create grafana_ns

osm ns-create --ns_name grafana-bug1837 --nsd_name grafana_ns --vim_account test-vim --config_file ./values-grafana.yaml

osm ns-action grafana-bug1837 --vnf_name grafana --kdu_name grafana --action_name upgrade --params_file ./upgrade-grafana.yaml

