#!/bin/bash

juju scale-application -m osm grafana 1
juju scale-application -m osm prometheus 1
juju scale-application -m osm kafka-k8s 1
juju scale-application -m osm keystone 1
juju scale-application -m osm lcm 1
juju scale-application -m osm mon 1
juju scale-application -m osm nbi 1
juju scale-application -m osm ng-ui 1
juju scale-application -m osm pol 1
juju scale-application -m osm ro 1
juju scale-application -m osm zookeeper-k8s 1

